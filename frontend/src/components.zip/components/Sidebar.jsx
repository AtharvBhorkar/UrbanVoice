import { useState, useRef, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import * as api from '../services/api';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Rss, PlaySquare, Crown, CirclePlus,
  ScanSearch, MessagesSquare, BellRing, User, Award,
  Settings, HelpCircle, LogOut, Menu, ImagePlus, Clapperboard, ClipboardList,} from 'lucide-react';
import logo from '../assets/logo.png';

const NAV_ITEMS = [
  { icon: Rss, label: 'Home Feed', to: '/feed' },
  { icon: PlaySquare, label: 'Voice Reels', to: '/reels' },
  { icon: ScanSearch, label: 'Search', to: '/search' },
  { icon: MessagesSquare, label: 'Messages', to: '/messages' },
  { icon: CirclePlus, label: 'Create', to: '/create' },
  { icon: Crown, label: 'Leaderboard', to: '/leaderboard' },
];

const PROFILE_MENU = [
  { icon: User, label: 'My Profile', to: '/profile' },
  { icon: ClipboardList, label: 'My Complaints', to: '/my-complaints' },
  { icon: Award, label: 'My Badges', to: '/my-badges' },
];

const MEDIA_BASE = 'http://localhost:5000';

export default function Sidebar() {
  const navigate = useNavigate();
  const { logout, user } = useAuth();
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const profileRef = useRef(null);
  const moreRef = useRef(null);
  const createRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
      if (moreRef.current && !moreRef.current.contains(e.target)) setMoreOpen(false);
      if (createRef.current && !createRef.current.contains(e.target)) setCreateOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const loadUnread = () => {
      api.getConversations()
        .then((res) => setUnreadMessages(res.data.filter((c) => c.unread).length))
        .catch(() => {});
    };
    loadUnread();
    const interval = setInterval(loadUnread, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.aside
      onMouseEnter={() => setExpanded(true)}
      onMouseLeave={() => { setExpanded(false); setProfileOpen(false); setMoreOpen(false); setCreateOpen(false); }}
      animate={{ width: expanded ? 240 : 76 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="hidden md:flex fixed left-0 top-0 bottom-0 z-40 bg-ink-950 border-r border-ink-800 flex-col justify-between py-6 overflow-visible"
    >
      <div>
        <NavLink to="/" className="flex items-center gap-3.5 px-[22px] mb-8">
          <img src={logo} alt="" className="w-8 h-8 object-contain shrink-0" />
          <span
            className={`font-display font-bold text-[17px] text-text-dark whitespace-nowrap transition-opacity duration-200 ${
              expanded ? 'opacity-100' : 'opacity-0'
            }`}
          >
            Urban<span className="text-volt">Voice</span>
          </span>
        </NavLink>

        <nav className="flex flex-col gap-1 px-3">
          {NAV_ITEMS.map((item) =>
            item.label === 'Create' ? (
              <div className="relative" ref={createRef} key={item.to}>
                <button
                  onClick={() => { setCreateOpen((v) => !v); setProfileOpen(false); setMoreOpen(false); }}
                  className={`w-full flex items-center gap-4 px-3 py-3 rounded-xl transition-colors whitespace-nowrap relative ${
                    createOpen
                      ? 'bg-ink-800 text-text-dark'
                      : 'text-text-dark-muted hover:bg-ink-900 hover:text-text-dark'
                  }`}
                >
                  <span className="relative shrink-0">
                    <item.icon size={22} strokeWidth={2} />
                  </span>
                  <span
                    className={`text-[14.5px] font-body font-medium transition-opacity duration-200 ${
                      expanded ? 'opacity-100' : 'opacity-0'
                    }`}
                  >
                    {item.label}
                  </span>
                </button>

                <AnimatePresence>
                  {createOpen && (
                    <motion.div
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -8 }}
                      transition={{ duration: 0.18 }}
                      className="absolute left-full top-0 ml-2 w-48 rounded-2xl bg-ink-900 border border-ink-700 shadow-2xl py-2 z-50"
                    >
                      <NavLink
                        to="/create"
                        onClick={() => setCreateOpen(false)}
                        className="flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-text-dark hover:bg-ink-800 transition-colors"
                      >
                        <ImagePlus size={17} />
                        Voice Post
                      </NavLink>
                      <NavLink
                        to="/create-reel"
                        onClick={() => setCreateOpen(false)}
                        className="flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-text-dark hover:bg-ink-800 transition-colors"
                      >
                        <Clapperboard size={17} />
                        Voice Reel
                      </NavLink>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-4 px-3 py-3 rounded-xl transition-colors whitespace-nowrap relative ${
                    isActive
                      ? 'bg-ink-800 text-text-dark'
                      : 'text-text-dark-muted hover:bg-ink-900 hover:text-text-dark'
                  }`
                }
              >
                <span className="relative shrink-0">
                  <item.icon size={22} strokeWidth={2} />
                  {item.label === 'Messages' && unreadMessages > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-signal text-[10px] font-bold text-white flex items-center justify-center">
                      {unreadMessages > 9 ? '9+' : unreadMessages}
                    </span>
                  )}
                </span>
                <span
                  className={`text-[14.5px] font-body font-medium transition-opacity duration-200 ${
                    expanded ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  {item.label}
                </span>
              </NavLink>
            )
          )}

        </nav>
      </div>

      <div className="flex flex-col gap-1 px-3">
        <NavLink
          to="/notifications"
          className={({ isActive }) =>
            `flex items-center gap-4 px-3 py-3 rounded-xl transition-colors whitespace-nowrap relative ${
              isActive
                ? 'bg-ink-800 text-text-dark'
                : 'text-text-dark-muted hover:bg-ink-900 hover:text-text-dark'
            }`
          }
        >
          <span className="relative shrink-0">
            <BellRing size={22} strokeWidth={2} />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-signal" />
          </span>
          <span
            className={`text-[14.5px] font-body font-medium transition-opacity duration-200 ${
              expanded ? 'opacity-100' : 'opacity-0'
            }`}
          >
            Notifications
          </span>
        </NavLink>

        <div className="relative" ref={profileRef}>
          <button
            onClick={() => { setProfileOpen((v) => !v); setMoreOpen(false); }}
            className="w-full flex items-center gap-4 px-3 py-3 rounded-xl text-text-dark-muted hover:bg-ink-900 hover:text-text-dark transition-colors whitespace-nowrap"
          >
            <span className="w-[22px] h-[22px] rounded-full bg-volt/20 border border-volt/40 flex items-center justify-center shrink-0 overflow-hidden">
              {user?.avatar ? (
                <img src={`${MEDIA_BASE}${user.avatar}`} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-volt text-[10px] font-bold font-body">{user?.username?.slice(0, 2).toUpperCase()}</span>
              )}
            </span>
            <span
              className={`text-[14.5px] font-body font-medium transition-opacity duration-200 ${
                expanded ? 'opacity-100' : 'opacity-0'
              }`}
            >
              Profile
            </span>
          </button>

          <AnimatePresence>
            {profileOpen && (
              <motion.div
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.18 }}
                className="absolute left-full bottom-0 ml-2 w-56 rounded-2xl bg-ink-900 border border-ink-700 shadow-2xl py-2"
              >
                {PROFILE_MENU.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className="flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-text-dark hover:bg-ink-800 transition-colors"
                  >
                    <item.icon size={17} />
                    {item.label}
                  </NavLink>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="relative" ref={moreRef}>
          <button
            onClick={() => { setMoreOpen((v) => !v); setProfileOpen(false); }}
            className="w-full flex items-center gap-4 px-3 py-3 rounded-xl text-text-dark-muted hover:bg-ink-900 hover:text-text-dark transition-colors whitespace-nowrap"
          >
            <Menu size={22} className="shrink-0" strokeWidth={2} />
            <span
              className={`text-[14.5px] font-body font-medium transition-opacity duration-200 ${
                expanded ? 'opacity-100' : 'opacity-0'
              }`}
            >
              More
            </span>
          </button>

          <AnimatePresence>
            {moreOpen && (
              <motion.div
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.18 }}
                className="absolute left-full bottom-0 ml-2 w-60 rounded-2xl bg-ink-900 border border-ink-700 shadow-2xl py-2"
              >
                <NavLink
                  to="/settings"
                  className="flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-text-dark hover:bg-ink-800 transition-colors"
                >
                  <Settings size={17} />
                  Settings
                </NavLink>
                <NavLink
                  to="/help"
                  className="flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-text-dark hover:bg-ink-800 transition-colors"
                >
                  <HelpCircle size={17} />
                  Help &amp; FAQ
                </NavLink>
                <div className="h-px bg-ink-700 my-1.5 mx-4" />

                <button
                  onClick={() => {
                    logout();
                    setMoreOpen(false);
                    navigate('/');
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-[14px] font-body text-signal hover:bg-ink-800 transition-colors"
                >
                  <LogOut size={17} />
                  Logout
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.aside>
  );
}